//
//  AcuantPassiveLiveness.h
//  AcuantPassiveLiveness
//
//  Created by John Moon local on 1/20/20.
//  Copyright © 2020 Acuant. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AcuantPassiveLiveness.
FOUNDATION_EXPORT double AcuantPassiveLivenessVersionNumber;

//! Project version string for AcuantPassiveLiveness.
FOUNDATION_EXPORT const unsigned char AcuantPassiveLivenessVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AcuantPassiveLiveness/PublicHeader.h>


