//
//  CameraSDK.h
//  CameraSDK
//
//  Created by Tapas Behera on 1/24/19.
//  Copyright © 2019 Tapas Behera. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CameraSDK.
FOUNDATION_EXPORT double AcuantCameraVersionNumber;

//! Project version string for CameraSDK.
FOUNDATION_EXPORT const unsigned char AcuantCameraVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CameraSDK/PublicHeader.h>


